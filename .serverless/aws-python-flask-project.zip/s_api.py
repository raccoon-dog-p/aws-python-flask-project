import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='raccoon94',
    application_name='aws-python-flask-project',
    app_uid='V8bng4Ph7DwSGrb7KW',
    org_uid='b355c397-275d-45e8-8bbe-7ec2ead1718d',
    deployment_uid='e63d215b-950d-4d66-91d7-f08742c064a3',
    service_name='aws-python-flask-project',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='6.1.5',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'aws-python-flask-project-dev-api', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('wsgi_handler.handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
